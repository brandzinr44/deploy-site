'use client'
import { useRef, useLayoutEffect, useState } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'

const text = "Ready to build something that lasts?"

function seededVal(index: number, salt: number) {
  const x = Math.sin(index * 127.1 + salt * 311.7) * 43758.5453
  return x - Math.floor(x)
}

const letterData = text.split('').map((char, i) => {
  const r = (s: number) => seededVal(i, s)
  return {
    char,
    peakY: -(r(1) * 55 + 15),
    peakX: (r(2) - 0.5) * 28,
    peakRotate: (r(3) - 0.5) * 30,
    peakScale: 1 + r(4) * 0.28,
    phaseOffset: (r(5) - 0.5) * 0.12,
    easeWidth: 0.12 + r(6) * 0.14,
  }
})

let wordIdx = 0
const letterWordMap: number[] = []
text.split('').forEach((char) => {
  letterWordMap.push(wordIdx)
  if (char === ' ') wordIdx++
})
const totalWords = wordIdx + 1

function DancingLetter({
  globalIndex,
  scrollProgress,
  fontSize,
}: {
  globalIndex: number
  scrollProgress: any
  fontSize: number
}) {
  const d = letterData[globalIndex]
  const wIdx = letterWordMap[globalIndex]

  if (d.char === ' ') {
    return <span style={{ display: 'inline-block', width: `${fontSize * 0.24}px` }} />
  }

  const wordPhase = wIdx / totalWords
  const peak = Math.min(1, Math.max(0, wordPhase + d.phaseOffset))
  const half = d.easeWidth
  const s = Math.max(0, peak - half)
  const e = Math.min(1, peak + half)

  const y = useTransform(scrollProgress, [s, peak, e], [0, d.peakY, 0])
  const x2 = useTransform(scrollProgress, [s, peak, e], [0, d.peakX, 0])
  const rotate = useTransform(scrollProgress, [s, peak, e], [0, d.peakRotate, 0])
  const scale = useTransform(scrollProgress, [s, peak, e], [1, d.peakScale, 1])

  return (
    <motion.span
      style={{
        y,
        x: x2,
        rotate,
        scale,
        display: 'inline-block',
        transformOrigin: 'bottom center',
      }}
    >
      {d.char}
    </motion.span>
  )
}

export default function ReadySection() {
  const containerRef = useRef<HTMLDivElement>(null)
  const textRef = useRef<HTMLDivElement>(null)
  const [dims, setDims] = useState<{ vw: number; tw: number; fs: number } | null>(null)

  useLayoutEffect(() => {
    function measure() {
      if (!textRef.current) return
      const isMobile = window.innerWidth < 768
      const fs = isMobile ? 100 : 232
      textRef.current.style.fontSize = `${fs}px`
      setDims({ vw: window.innerWidth, tw: textRef.current.scrollWidth, fs })
    }
    measure()
    window.addEventListener('resize', measure)
    return () => window.removeEventListener('resize', measure)
  }, [])

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end end'],
  })

  const startX = dims ? dims.vw : 99999
  const endX = dims ? -dims.tw : 99999
  const fs = dims?.fs ?? 232

  const x = useTransform(scrollYProgress, [0, 1], [startX, endX])

  return (
    <div ref={containerRef} style={{ height: '700vh', position: 'relative' }}>
      <div className="sticky top-0 h-screen w-screen flex items-center overflow-hidden bg-background">
        <motion.div
          ref={textRef}
          style={{
            x,
            display: 'flex',
            alignItems: 'flex-end',
            whiteSpace: 'nowrap',
            willChange: 'transform',
            fontFamily: '"Inter',
            fontWeight: 500,
            fontSize: `${fs}px`,
            color: 'var(--foreground)',
            letterSpacing: '-0.03em',
            lineHeight: 1,
            position: 'absolute',
            left: 0,
            paddingBottom: '80px',
          }}
        >
          {text.split('').map((_, i) => (
            <DancingLetter
              key={i}
              globalIndex={i}
              scrollProgress={scrollYProgress}
              fontSize={fs}
            />
          ))}
        </motion.div>
      </div>
    </div>
  )
}
