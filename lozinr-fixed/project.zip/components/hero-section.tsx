'use client'

import React, { useState, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Work from '@/components/work'
import Process from '@/components/process'
import FooterSection from '@/components/footer-section'

interface HeroSectionProps {
  triggerAnimation?: boolean
}

const ROTATING_WORDS = ['Founders', 'Startups', 'D2C Brands']

export default function HeroSection({ triggerAnimation = false }: HeroSectionProps) {
  const sectionRef = useRef<HTMLSectionElement>(null)
  const [wordIndex, setWordIndex] = useState(0)

  React.useEffect(() => {
    const interval = setInterval(() => {
      setWordIndex((prev) => (prev + 1) % ROTATING_WORDS.length)
    }, 2800)
    return () => clearInterval(interval)
  }, [])

  return (
    <main className="min-h-screen bg-background">

      {/* Hero Logo Section — space for preloader logo handoff */}
      <section ref={sectionRef} className="bg-background overflow-hidden pt-0 py-10 md:py-20">
        <div className="w-full px-3 lg:px-5" />
      </section>

      {/* Hero Content */}
      <section className="bg-background pt-20 md:pt-20 flex items-center justify-center min-h-[60vh]">
        <div className="px-3 lg:px-6 pb-6 md:pb-8">
          <div className="flex flex-col gap-4 items-center">

            {/* H1 */}
            <div className="overflow-hidden flex justify-center">
              <motion.h1
                initial={{ y: '100%', opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.55, ease: [0.16, 1, 0.3, 1] }}
                className="text-[32px] md:text-[52px] font-medium tracking-tighter leading-[1] text-foreground text-center"
              >
                Premium Branding for{' '}

                {/* Rotating word — invisible widest word holds layout width */}
                <span className="inline-block relative" style={{ verticalAlign: 'baseline' }}>
                  <span className="invisible whitespace-nowrap text-[#C4714F]" aria-hidden>
                    D2C Brands
                  </span>
                  <span
                    className="absolute inset-0 overflow-hidden"
                    style={{ clipPath: 'inset(0 0 0 0)' }}
                  >
                    <AnimatePresence mode="popLayout">
                      <motion.span
                        key={wordIndex}
                        initial={{ y: '100%' }}
                        animate={{ y: 0 }}
                        exit={{ y: '-100%' }}
                        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                        className="block text-[#C4714F] whitespace-nowrap"
                      >
                        {ROTATING_WORDS[wordIndex]}
                      </motion.span>
                    </AnimatePresence>
                  </span>
                </span>
              </motion.h1>
            </div>



          </div>
        </div>
      </section>

      <Work />
      <Process />
      <FooterSection />
    </main>
  )
}
