'use client'

import { useState, useEffect, useRef } from 'react'
import { motion, useInView, animate as animateValue } from 'framer-motion'
import ReadySection from './ready-section'

const leftCards = [
  {
    id: 1,
    number: '01',
    title: 'Discovery',
    description: 'Before we design a single pixel, we need to understand everything about your business. Discovery is where we ask the questions most designers never ask — about your audience, your competitors, your values, and the feeling you want your brand to create.',
    deliverables: [
      'Brand discovery questionnaire & deep-dive interview',
      'Competitor landscape analysis',
      'Target audience profiling',
      'Brand audit (if rebranding)',
      'Brand values & positioning workshop',
    ],
  },
  {
    id: 2,
    number: '02',
    title: 'Strategy',
    description: "Discovery tells us where you are. Strategy decides where you're going — and how your brand gets you there. This is where we define your brand's positioning, personality, voice, and the story you'll tell the world.",
    deliverables: [
      'Brand positioning statement',
      'Brand personality framework',
      'Voice & tone guidelines',
      'Messaging pillars',
      'Ideal buyer persona',
    ],
  },
  {
    id: 3,
    number: '03',
    title: 'Visual Direction',
    description: 'Before a single logo is drawn, we define the aesthetic language of your brand — the mood, the feeling, the world it lives in. This ensures every design decision that follows is intentional, not accidental.',
    deliverables: [
      '3 distinct moodboard concepts',
      'Color palette exploration',
      'Typography direction',
      'Aesthetic & style references',
      'Feedback & approval session',
    ],
  },
]

const rightCards = [
  {
    id: 4,
    number: '04',
    title: 'Identity',
    description: 'This is where strategy becomes visual. Using the approved direction, we design your complete brand identity system — every element crafted with intention, every decision rooted in your strategy.',
    deliverables: [
      'Primary logo & variations',
      'Brand mark & icon set',
      'Color system & specifications',
      'Typography system',
      'Supporting graphics & patterns',
      'Brand mark documentation',
    ],
  },
  {
    id: 5,
    number: '05',
    title: 'Guidelines',
    description: 'A brand without guidelines is a brand without protection. Your Brand Guidelines ensure your identity stays consistent and powerful — across every platform, every touchpoint, forever.',
    deliverables: [
      'Brand guidelines document',
      'Logo usage rules & restrictions',
      'Color & typography standards',
      'Application examples',
      'Digital & print asset formats',
      'Full asset library',
    ],
  },
]

// ─── Count Up Number ─────────────────────────────────────────────
function CountUpNumber({
  value,
  isHovered,
  inView,
}: {
  value: string
  isHovered: boolean
  inView: boolean
}) {
  const [display, setDisplay] = useState('00')

  useEffect(() => {
    if (!inView) return
    const num = parseInt(value)
    if (isNaN(num)) return
    const controls = animateValue(0, num, {
      duration: 0.8,
      ease: 'easeOut',
      onUpdate: (v) => setDisplay(String(Math.round(v)).padStart(2, '0')),
    })
    return () => controls.stop()
  }, [inView, value])

  return (
    <motion.span
      className="text-[60px] font-light leading-none select-none tracking-tighter text-background/20"
      animate={{ scale: isHovered ? 1.1 : 1 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
    >
      {display}
    </motion.span>
  )
}

// ─── Process Card ────────────────────────────────────────────────
const ProcessCard = ({
  step,
  className = '',
  enterFrom = 'bottom',
  index = 0,
}: {
  step: (typeof leftCards)[0]
  className?: string
  enterFrom?: 'top' | 'bottom'
  index?: number
}) => {
  const [isHovered, setIsHovered] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true, margin: '-60px' })

  const listItemVariants = {
    initial: { opacity: 0, x: -16 },
    animate: (i: number) => ({
      opacity: 1,
      x: 0,
      transition: { delay: i * 0.06, duration: 0.35, ease: [0.16, 1, 0.3, 1] },
    }),
  }

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: enterFrom === 'top' ? -40 : 40 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.8, delay: index * 0.1, ease: [0.16, 1, 0.3, 1] }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`relative p-4 md:p-5 flex flex-row items-start justify-between gap-4 overflow-hidden cursor-pointer ${className}`}
      style={{
        backgroundColor: isHovered
          ? 'rgba(255, 255, 255 / 0.12)'
          : 'rgba(255, 255, 255 / 0.08)',
      }}
    >
      {/* Left — Title + Description + Deliverables */}
      <div className="relative flex-[70%] flex flex-col z-10">
        <motion.h3
          className="text-[16px] font-medium tracking-tighter leading-tight mb-3 text-background"
          animate={{ y: isHovered ? -2 : 0 }}
          transition={{ duration: 0.3 }}
        >
          {step.title}
        </motion.h3>

        <motion.p
          animate={{ opacity: isHovered ? 1 : 0.6 }}
          transition={{ duration: 0.3 }}
          className={`text-[16px] leading-tight font-normal tracking-tight text-background transition-all duration-500 ${isHovered ? '' : 'line-clamp-3'}`}
        >
          {step.description}
        </motion.p>

        {/* Deliverables */}
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{
            opacity: isHovered ? 1 : 0,
            height: isHovered ? 'auto' : 0,
            marginTop: isHovered ? 16 : 0,
          }}
          transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
          className="overflow-hidden"
        >
          <div className="pt-4 border-t border-background/20">
            <h4 className="text-[16px] font-medium tracking-tight text-background/70 mb-3">
              What We Deliver
            </h4>
            <ul className="space-y-2">
              {step.deliverables?.map((item, i) => (
                <motion.li
                  key={i}
                  custom={i}
                  variants={listItemVariants}
                  initial="initial"
                  animate={isHovered ? 'animate' : 'initial'}
                  className="text-[16px] font-medium text-background/70 tracking-tight flex items-start gap-2"
                >
                  <span className="flex-shrink-0 mt-0.5 text-background/40">▸</span>
                  <span className="leading-snug">{item}</span>
                </motion.li>
              ))}
            </ul>
          </div>
        </motion.div>
      </div>

      {/* Right — Count Up Number */}
      <div className="relative flex-[30%] flex items-start justify-end flex-shrink-0 z-10">
        <CountUpNumber value={step.number} isHovered={isHovered} inView={inView} />
      </div>
    </motion.div>
  )
}

// ─── Main ────────────────────────────────────────────────────────
export default function Process() {
  const titleRef = useRef(null)
  const titleInView = useInView(titleRef, { once: true, margin: '-100px' })

  return (
    <div className="w-full bg-foreground text-background py-20 md:py-10 px-3 lg:px-6">

      {/* Title */}
      <motion.div
        ref={titleRef}
        initial={{ opacity: 0, y: 20 }}
        animate={titleInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="mb-3 md:mb-5"
      >
        <h2 className="text-[16px] font-medium text-background tracking-tighter leading-[0.9]">
          Process
        </h2>
      </motion.div>

      {/* Grid */}
      <div className="max-w-full mx-auto">

        {/* Desktop */}
        <div className="hidden md:grid md:grid-cols-2 gap-2">
          <div className="flex flex-col gap-2">
            {leftCards.map((step, i) => (
              <ProcessCard key={step.id} step={step} enterFrom="bottom" index={i} />
            ))}
          </div>
          <div className="flex flex-col gap-2">
            <ProcessCard step={rightCards[0]} enterFrom="top" index={0} className="min-h-[257px]" />
            <ProcessCard step={rightCards[1]} enterFrom="top" index={1} className="min-h-[200px]" />
          </div>
        </div>

        {/* Mobile */}
        <div className="md:hidden flex flex-col gap-3">
          {[...leftCards, ...rightCards].map((step, i) => (
            <ProcessCard key={step.id} step={step} enterFrom="bottom" index={i} />
          ))}
        </div>
      </div>

      <ReadySection />
    </div>
  )
}
