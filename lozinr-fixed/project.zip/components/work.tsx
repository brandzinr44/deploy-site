'use client'

import { motion, useMotionValue, useSpring } from 'framer-motion'
import Image from 'next/image'
import Link from 'next/link'
import { useRef, useState } from 'react'
import { projectsData } from '@/lib/projects-data'

// ─── Card ────────────────────────────────────────────────────────
function TiltCard({
  project,
  sizes,
  className = '',
}: {
  project: (typeof projectsData)[0]
  sizes: string
  className?: string
}) {
  const cardRef = useRef<HTMLDivElement>(null)
  const [hovered, setHovered] = useState(false)

  const rotateX = useMotionValue(0)
  const rotateY = useMotionValue(0)
  const springRotateX = useSpring(rotateX, { stiffness: 120, damping: 20 })
  const springRotateY = useSpring(rotateY, { stiffness: 120, damping: 20 })

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = cardRef.current?.getBoundingClientRect()
    if (!rect) return
    const cx = rect.left + rect.width / 2
    const cy = rect.top + rect.height / 2
    rotateX.set(((e.clientY - cy) / rect.height) * -10)
    rotateY.set(((e.clientX - cx) / rect.width) * 10)
  }

  const handleMouseLeave = () => {
    rotateX.set(0)
    rotateY.set(0)
    setHovered(false)
  }

  return (
    <div className={`group ${className}`}>
      <Link href={`/projects/${project.name.toLowerCase().replace(/\s+/g, '-')}`}>
        <motion.div
          ref={cardRef}
          onMouseMove={handleMouseMove}
          onMouseEnter={() => setHovered(true)}
          onMouseLeave={handleMouseLeave}
          style={{
            rotateX: springRotateX,
            rotateY: springRotateY,
            transformStyle: 'preserve-3d',
            perspective: 800,
          }}
          className="cursor-pointer"
        >
          {/* Image */}
          <div
            className="relative w-full overflow-hidden bg-foreground/10"
            style={{ aspectRatio: '16/9' }}
          >
            <Image
              src={project.images[0]}
              alt={project.name}
              fill
              sizes={sizes}
              className="object-cover"
            />
          </div>

          {/* Info — Pentagram style */}
          <div className="pt-3 flex flex-col gap-1">

            {/* Title */}
            <h3 className="text-[16px] md:text-[16px] font-medium text-foreground tracking-tight leading-tight">
              {project.name}
            </h3>

            {/* Description */}
            <p className="text-[16px] font-medium text-foreground/60 leading-tight tracking-tight">
              {project.description}
            </p>

            {/* Industry tag — visible on hover */}
            <motion.div
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: hovered ? 1 : 0, y: hovered ? 0 : 6 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="mt-1"
            >
              <span className="inline-block text-[11px] md:text-[12px] bg-foreground/10 font-medium tracking-tight text-foreground rounded-full px-3 py-1">
                {project.industry}
              </span>
            </motion.div>

          </div>
        </motion.div>
      </Link>
    </div>
  )
}

// ─── Main ────────────────────────────────────────────────────────
export default function Work() {
  const displayProjects = projectsData.filter((p) => p.images[0] !== '#')

  return (
    <section
      id="work-section"
      className="bg-background py-12 md:py-24 px-3 lg:px-6"
    >
      {/* Section title */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-100px' }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="mb-4 md:mb-6"
      >
        <h2 className="text-[16px] font-medium text-foreground tracking-tight leading-[0.9]">
          Selected Work
        </h2>
      </motion.div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 md:gap-3">
        {displayProjects.map((project) => (
          <TiltCard
            key={project.id}
            project={project}
            sizes="(max-width: 768px) 100vw, 50vw"
          />
        ))}
      </div>
    </section>
  )
}