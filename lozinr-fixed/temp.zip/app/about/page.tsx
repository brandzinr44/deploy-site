'use client'

import { useEffect, useState, useRef } from 'react'
import { motion, useInView, useScroll, useTransform } from 'framer-motion'
import Header from '@/components/header'
import FooterSection from '@/components/footer-section'

const storyLines = [
  "Lozinr started with a single question —",
  "why do some brands feel expensive",
  "before you even see the price?",
  "The answer was always the same:",
  "strategy, craft, and an obsession",
  "with the details nobody notices",
  "but everybody feels.",
  "That obsession became Lozinr.",
  "And it drives everything we build.",
]

const storyLinesMobile = [
  "Lozinr started with a single question —",
  "why do some brands feel expensive",
  "before you even see the price?",
  "The answer was always the same:",
  "strategy, craft, and an obsession",
  "with the details nobody notices",
  "but everybody feels.",
  "That obsession became Lozinr.",
  "And it drives everything we build.",
]

const manifestoWords = [
  "Your", "brand", "is", "the", "first", "thing", "people", "feel",
  "before", "they", "read", "a", "word.", "Make", "sure",
  "it", "feels", "like", "something", "worth", "remembering."
]

const aboutLines = [
  "I'm Adnan Akif — a self-taught brand designer",
  "obsessed with the details nobody notices,",
  "but everybody feels.",
  "I don't just design logos. I build identities",
  "that make founders unforgettable.",
]

const aboutMobileLines = [
  "I'm Adnan Akif — self-taught,",
  "obsessed with the details",
  "nobody notices, but everybody feels.",
]

const socialLinks = [
  { name: 'Instagram', url: 'https://www.instagram.com/adnanahmedakif/' },
  { name: 'Youtube', url: 'https://www.youtube.com/adnanahmedakif' },
  { name: 'Facebook', url: 'https://web.facebook.com/adnan.o.akif' },
]

// ─── Word Reveal ──────────────────────────────────────────────────
function WordReveal({
  word,
  progress,
  start,
  end,
}: {
  word: string
  progress: any
  start: number
  end: number
}) {
  const opacity = useTransform(progress, [start, end], [0.1, 1])

  return (
    <motion.span
      style={{ opacity }}
      className="inline-block mr-[0.25em] text-foreground"
    >
      {word}
    </motion.span>
  )
}

// ─── Scroll Manifesto ─────────────────────────────────────────────
function ScrollManifesto() {
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end end'],
  })

  return (
    <div
      ref={containerRef}
      className="relative"
      style={{ height: '300vh' }}
    >
      <div className="sticky top-0 h-screen flex items-center overflow-hidden bg-background">
        <div className="px-2 lg:px-4 w-full">
          <div className="text-[36px] lg:text-[70px] font-medium tracking-tighter leading-[0.9] text-foreground">
            <span className="text-foreground">©</span>{' '}
            {manifestoWords.map((word, i) => {
              const start = i / manifestoWords.length
              const end = (i + 1) / manifestoWords.length
              return (
                <WordReveal
                  key={i}
                  word={word}
                  progress={scrollYProgress}
                  start={start}
                  end={end}
                />
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Social Link ──────────────────────────────────────────────────
function SocialLink({ link }: { link: (typeof socialLinks)[0] }) {
  const containerRef = useRef<HTMLAnchorElement>(null)
  const [underlineWidth, setUnderlineWidth] = useState(0)

  useEffect(() => {
    if (containerRef.current) {
      setUnderlineWidth(containerRef.current.offsetWidth)
    }
  }, [])

  return (
    <motion.a
      ref={containerRef}
      href={link.url}
      target="_blank"
      rel="noopener noreferrer"
      className="relative inline-flex items-center gap-1 group w-fit"
      whileHover="hover"
      initial="normal"
    >
      <span className="text-[14px] md:text-[18px] font-medium text-foreground tracking-tighter transition-colors duration-200">
        {link.name}
      </span>
      <motion.span
        className="text-foreground flex-shrink-0"
        variants={{ normal: { opacity: 0.3 }, hover: { opacity: 1 } }}
        transition={{ duration: 0.2 }}
      >
        <svg width="16" height="16" viewBox="0 0 288.4 227.36" fill="currentColor" className="w-4 h-4">
          <path d="M227.56,6.91c-.17.17-.8.8-1.87,1.7-34.55,29.66-68.6,5.42-78.22-2.72l-4.81-4.07-21.16,33.51,4.53,2.96c1.42.93,27.7,17.79,53.98,15.99L33.37,200.91l23.91,23.91L203.59,78.51c-1.48,26.08,15.12,51.96,16.02,53.34l2.96,4.53,33.51-21.16-4.07-4.81c-12.86-15.19-18.5-30.87-16.79-46.58,1.36-12.5,7.01-22.37,11.6-28.53l8.53-8.53-23.82-23.82-3.97,3.97h-.01Z" />
        </svg>
      </motion.span>
      <motion.span
        className="absolute bottom-0 left-0 h-[1px] bg-foreground"
        variants={{ normal: { scaleX: 0 }, hover: { scaleX: 1 } }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
        style={{ width: underlineWidth || 'auto', originX: 0 }}
      />
    </motion.a>
  )
}

// ─── Founder Section ──────────────────────────────────────────────
function FounderSection() {
  const dividerRef = useRef(null)
  const dividerInView = useInView(dividerRef, { once: false, margin: '-40px' })
  const imageRef = useRef(null)
  const aboutTextRef = useRef(null)
  const aboutTextInView = useInView(aboutTextRef, { once: false, margin: '-60px' })

  return (
    <div className="bg-transparent">
      <div ref={dividerRef} className="px-2 lg:px-4">
        <motion.div
          className="w-full h-px bg-foreground"
          initial={{ scaleX: 0 }}
          animate={dividerInView ? { scaleX: 1 } : { scaleX: 0 }}
          style={{ originX: 0 }}
          transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
        />
      </div>

      <div className="px-2 lg:px-4 pt-16 md:pt-20 pb-20 md:pb-28 border-b border-foreground">

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: false, margin: '-80px' }}
          transition={{ duration: 0.5 }}
          className="md:hidden text-[14px] font-medium tracking-tight text-foreground/40 mb-4"
        >
          Our founder
        </motion.p>

        {/* Desktop: 40% empty left + 60% content | Mobile: single column */}
        <div className="hidden md:grid md:grid-cols-[40%_60%]">
          {/* Left — empty spacer */}
          <div />
          {/* Right — founder content */}
          <div className="grid grid-cols-[1.2fr_1.5fr] gap-12 items-start">

          {/* Image */}
<motion.div
  ref={imageRef}
  initial={{ opacity: 0, y: 40 }}
  whileInView={{ opacity: 1, y: 0 }}
  viewport={{ once: false, margin: '-80px' }}
  transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
  className="relative w-full overflow-hidden"
  style={{ aspectRatio: '1/1.2' }}
>
  <img
    src="https://sork85p59iwczwgh.public.blob.vercel-storage.com/Adnan.png"
    alt="About image"
    className="w-full h-full object-cover"
  />
</motion.div>

            {/* Right — text */}
            <div ref={aboutTextRef} className="flex flex-col gap-10">

            {/* Desktop — 4 lines */}
            <div className="hidden md:flex flex-col gap-0">
              {aboutLines.map((line, i) => (
                <div key={i} className="overflow-hidden">
                  <motion.span
                    className="block text-[18px] font-medium tracking-tighter leading-tight text-foreground"
                    initial={{ y: '100%' }}
                    animate={aboutTextInView ? { y: 0 } : { y: '100%' }}
                    transition={{ duration: 0.65, delay: i * 0.06, ease: [0.16, 1, 0.3, 1] }}
                  >
                    {line}
                  </motion.span>
                </div>
              ))}
            </div>

            {/* Mobile — 3 lines */}
            <div className="md:hidden flex flex-col gap-0">
              {aboutMobileLines.map((line, i) => (
                <div key={i} className="overflow-hidden">
                  <motion.span
                    className="block text-[14px] font-medium tracking-tighter leading-tight text-foreground"
                    initial={{ y: '100%' }}
                    whileInView={{ y: 0 }}
                    viewport={{ once: false, margin: '-40px' }}
                    transition={{ duration: 0.65, delay: i * 0.06, ease: [0.16, 1, 0.3, 1] }}
                  >
                    {line}
                  </motion.span>
                </div>
              ))}
            </div>

            {/* Name + role */}
            <div>
              <p className="text-[14px] md:text-[18px] font-medium text-foreground tracking-tighter">
                Adnan Akif
              </p>
              <p className="text-[14px] md:text-[18px] font-medium text-foreground/50 tracking-tighter mt-0.5">
                Founder & Brand Designer
              </p>
            </div>

            {/* Socials */}
            <div className="flex flex-col gap-1">
              {socialLinks.map((link) => (
                <SocialLink key={link.name} link={link} />
              ))}
            </div>
          </div>
          </div>{/* end right 80% */}
        </div>{/* end desktop grid */}

        {/* Mobile layout — single column */}
        <div className="md:hidden flex flex-col gap-8">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false, margin: '-80px' }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full overflow-hidden"
            style={{ aspectRatio: '1/1.2' }}
          >
            <div className="w-full h-full bg-foreground flex items-center justify-center" />
          </motion.div>

          {/* About text — mobile 3 lines */}
          <div className="flex flex-col gap-0">
            {aboutMobileLines.map((line, i) => (
              <div key={i} className="overflow-hidden">
                <motion.span
                  className="block text-[14px] font-medium tracking-tighter leading-tight text-foreground"
                  initial={{ y: '100%' }}
                  whileInView={{ y: 0 }}
                  viewport={{ once: false, margin: '-40px' }}
                  transition={{ duration: 0.65, delay: i * 0.06, ease: [0.16, 1, 0.3, 1] }}
                >
                  {line}
                </motion.span>
              </div>
            ))}
          </div>

          {/* Name + role */}
          <div>
            <p className="text-[14px] font-medium text-foreground tracking-tighter">Adnan Akif</p>
            <p className="text-[14px] font-medium text-foreground/50 tracking-tighter mt-0.5">Founder & Brand Designer</p>
          </div>

          {/* Socials */}
          <div className="flex flex-col gap-1">
            {socialLinks.map((link) => (
              <SocialLink key={link.name} link={link} />
            ))}
          </div>
        </div>

      </div>
    </div>
  )
}

// ─── Team Member Card ─────────────────────────────────────────────
function TeamMemberCard({
  image,
  name,
  role,
  delay = 0
}: {
  image: string
  name: string
  role: string
  delay?: number
}) {
  const cardRef = useRef(null)
  const cardInView = useInView(cardRef, { once: false, margin: '-60px' })

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 40 }}
      animate={cardInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
      transition={{ duration: 0.7, delay, ease: [0.16, 1, 0.3, 1] }}
      className="flex flex-col gap-1"
    >
      <div className="w-full [aspect-square] overflow-hidden bg-background">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover object-center grayscale hover:grayscale-0 transition-all duration-500"
        />
      </div>
      <div>
        <p className="text-[14px] font-medium text-foreground tracking-tighter">{name}</p>
        <p className="text-[14px] font-medium text-foreground/50 tracking-tighter">{role}</p>
      </div>
    </motion.div>
  )
}

// ─── Team Section ─────────────────────────────────────────────────
function TeamSection() {
  const teamRef = useRef(null)
  const teamInView = useInView(teamRef, { once: false, margin: '-80px' })
  const titleRef = useRef(null)

  const teamMembers = [
    { image: "#", name: "Unknown", role: "No Role Yet" },
    { image: "#", name: "Unknown", role: "No Role Yet" },
    { image: "#", name: "Unknown", role: "No Role Yet" },
    { image: "#", name: "Unknown", role: "No Role Yet" },
    { image: "#", name: "Unknown", role: "No Role Yet" },
  ]

  return (
    <div className="bg-transparent py-20 md:py-28">
      <div className="px-2 lg:px-4">
        <div ref={titleRef} className="overflow-hidden mb-10 md:mb-16">
          <motion.h2
            initial={{ y: '100%', opacity: 0 }}
            animate={teamInView ? { y: 0, opacity: 1 } : { y: '100%', opacity: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="text-[24px] md:text-[36px] font-medium text-foreground/50 tracking-tighter leading-tight"
          >
            Team
          </motion.h2>
        </div>

        <div ref={teamRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 md:gap-8">
          {teamMembers.map((member, i) => (
            <TeamMemberCard
              key={i}
              image={member.image}
              name={member.name}
              role={member.role}
              delay={i * 0.08}
            />
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── Main ─────────────────────────────────────────────────────────
export default function AboutPage() {
  const [isMounted, setIsMounted] = useState(false)

  const titleRef = useRef(null)
  const titleInView = useInView(titleRef, { once: false, margin: '-80px' })

  const heroImageRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress: heroScroll } = useScroll({
    target: heroImageRef,
    offset: ['start end', 'end start'],
  })
  const heroImageY = useTransform(heroScroll, [0, 1], ['-24%', '24%'])
  const heroImageScale = useTransform(heroScroll, [0, 1], [1.1, 1.0])

  const dividerRef = useRef(null)
  const dividerInView = useInView(dividerRef, { once: false, margin: '-40px' })

  const storyTitleRef = useRef(null)
  const storyTitleInView = useInView(storyTitleRef, { once: false, margin: '-60px' })

  const storyTextRef = useRef(null)
  const storyTextInView = useInView(storyTextRef, { once: false, margin: '-60px' })

  useEffect(() => {
    setIsMounted(true)
  }, [])

  return (
    <main className="min-h-screen bg-background flex flex-col">
      <Header preloaderDone={true} />

      <section className="flex-1 flex flex-col pt-20 lg:pt-36">

        {/* Title */}
        <div ref={titleRef} className="overflow-hidden px-2 lg:px-4">
          <motion.h1
            initial={{ y: '100%', opacity: 0 }}
            animate={isMounted && titleInView ? { y: 0, opacity: 1 } : { y: '100%', opacity: 0 }}
            transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
            className="text-[59px] lg:text-[160px] font-regular text-foreground tracking-tighter text-left leading-tight"
          >
            About
          </motion.h1>
        </div>

        {/* Hero image — scroll parallax, full width */}
<div
  ref={heroImageRef}
  className="w-screen -mx-[calc(50vw-50%)] mt-6 md:mt-8 overflow-hidden"
  style={{ height: 'clamp(280px, 55vw, 700px)' }}
>
  <motion.div
    className="w-full h-full"
    style={{ y: heroImageY }}
  >
    <img
      src="https://sork85p59iwczwgh.public.blob.vercel-storage.com/abouthero.jpg"
      alt="About Lozinr"
      className="w-full h-full object-cover object-center"
    />
  </motion.div>
</div>

        {/* Divider */}
        <div ref={dividerRef} className="mt-12 md:mt-16 px-2 lg:px-4">
          <motion.div
            className="w-full h-px bg-foreground"
            initial={{ scaleX: 0 }}
            animate={dividerInView ? { scaleX: 1 } : { scaleX: 0 }}
            style={{ originX: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          />
        </div>

        {/* Studio Story */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-10 py-12 md:py-16 px-2 lg:px-4">

          <div ref={storyTitleRef} className="overflow-hidden">
            <motion.h2
              initial={{ y: '100%', opacity: 0 }}
              animate={storyTitleInView ? { y: 0, opacity: 1 } : { y: '100%', opacity: 0 }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              className="text-[18px] md:text-[36px] font-medium tracking-tighter text-foreground leading-tight"
            >
              Studio Story
            </motion.h2>
          </div>

          {/* Desktop story lines */}
          <div ref={storyTextRef} className="hidden md:flex flex-col">
            {storyLines.map((line, i) => (
              <div key={i} className="overflow-hidden">
                <motion.span
                  className="block text-[18px] md:text-[36px] font-medium tracking-tighter leading-[1.1] text-foreground"
                  initial={{ y: '100%' }}
                  animate={storyTextInView ? { y: 0 } : { y: '100%' }}
                  transition={{ duration: 0.65, delay: i * 0.05, ease: [0.16, 1, 0.3, 1] }}
                >
                  {line}
                </motion.span>
              </div>
            ))}
          </div>

          {/* Mobile story lines */}
          <div className="md:hidden flex flex-col">
            {storyLinesMobile.map((line, i) => (
              <div key={i} className="overflow-hidden">
                <motion.span
                  className="block text-[18px] font-medium tracking-tighter leading-[1.2] text-foreground"
                  initial={{ y: '100%' }}
                  whileInView={{ y: 0 }}
                  viewport={{ once: false, margin: '-40px' }}
                  transition={{ duration: 0.65, delay: i * 0.04, ease: [0.16, 1, 0.3, 1] }}
                >
                  {line}
                </motion.span>
              </div>
            ))}
          </div>

        </div>

      </section>

      {/* Scroll Manifesto */}
      <ScrollManifesto />

      {/* Founder Section */}
      <FounderSection />

      {/* Team Section */}
      <TeamSection />

      <FooterSection />
    </main>
  )
}
