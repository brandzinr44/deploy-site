import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'About Lozinr — Brand Identity Designer Adnan Akif',
  description: 'Lozinr is founded by Adnan Akif, a self-taught brand identity designer obsessed with building brands that feel expensive before you see the price.',
  keywords: [
    'Adnan Akif',
    'brand identity designer',
    'self-taught designer',
    'brand designer portfolio',
    'branding expert',
    'visual identity designer',
    'brand strategy',
  ],
  alternates: {
    canonical: 'https://lozinr.com/about',
  },
}

export default function AboutLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
