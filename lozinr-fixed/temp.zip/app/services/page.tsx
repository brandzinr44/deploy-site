import type { Metadata } from 'next'
import ServicesClient from '@/components/services-client'

export const metadata: Metadata = {
  title: 'Brand Identity Design & Logo Design Services | Lozinr Branding Agency',
  description: 'Premium brand identity design, logo design, and brand strategy services for startups. Lozinr is a branding agency built for founders who take their brand seriously.',
  keywords: [
    'brand identity design',
    'logo design services',
    'branding agency',
    'brand strategy',
    'visual identity design',
    'logo design agency',
    'startup branding',
    'brand guidelines',
  ],
  alternates: {
    canonical: 'https://lozinr.com/services',
  },
}

// JSON-LD Schema for Services
const servicesSchema = {
  '@context': 'https://schema.org',
  '@type': 'CollectionPage',
  name: 'Branding Services',
  description: 'Premium branding services for tech startups and SaaS companies',
  hasPart: [
    {
      '@type': 'Service',
      name: 'Brand Identity Design',
      description: 'Custom brand identity systems and visual design for startups',
      provider: {
        '@type': 'Organization',
        name: 'Lozinr',
      },
      areaServed: ['US', 'UK'],
    },
    {
      '@type': 'Service',
      name: 'Logo Design',
      description: 'Professional logo design and brand mark systems',
      provider: {
        '@type': 'Organization',
        name: 'Lozinr',
      },
      areaServed: ['US', 'UK'],
    },
    {
      '@type': 'Service',
      name: 'Brand Strategy',
      description: 'Strategic brand positioning and messaging framework',
      provider: {
        '@type': 'Organization',
        name: 'Lozinr',
      },
      areaServed: ['US', 'UK'],
    },
  ],
}

export default function ServicesPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(servicesSchema),
        }}
      />
      <ServicesClient />
    </>
  )
}
