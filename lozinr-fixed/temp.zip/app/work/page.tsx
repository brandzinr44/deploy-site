'use client'

import { useRef, useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { motion, useMotionValue, useSpring } from 'framer-motion'
import Header from '@/components/header'
import FooterSection from '@/components/footer-section'
import { projectsData } from '@/lib/projects-data'

export default function WorkPage() {
  const displayProjects = projectsData.filter((p) => p.images[0] !== '#')

  return (
    <>
      <Header preloaderDone={true} />
      <main className="min-h-screen bg-background text-white">

        {/* Title */}
        <div className="px-3 lg:px-6 pt-20 lg:pt-36 pb-10 overflow-hidden">
          <h1 className="text-[50px] inline-block overflow-hidden font-regular text-foreground tracking-tighter text-left leading-tight">
            <motion.span
              className="inline-block"
              initial={{ y: '100%' }}
              whileInView={{ y: 0 }}
              viewport={{ once: false, margin: '-80px' }}
              transition={{
                duration: 0.85,
                ease: [0.16, 1, 0.3, 1],
              }}
            >
              Work
            </motion.span>
          </h1>
        </div>

        {/* Projects Grid */}
        <div className="px-3 lg:px-6 pb-20">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 md:gap-3">
            {displayProjects.map((project) => (
              <TiltCard
                key={project.id}
                project={project}
                sizes="(max-width: 768px) 100vw, 50vw"
              />
            ))}
          </div>
        </div>
      </main>
      <FooterSection />
    </>
  )
}

// ─── Card ────────────────────────────────────────────────────────
function TiltCard({
  project,
  sizes,
  className = '',
}: {
  project: (typeof projectsData)[0]
  sizes: string
  className?: string
}) {
  const cardRef = useRef<HTMLDivElement>(null)
  const [hovered, setHovered] = useState(false)

  const rotateX = useMotionValue(0)
  const rotateY = useMotionValue(0)
  const springRotateX = useSpring(rotateX, { stiffness: 120, damping: 20 })
  const springRotateY = useSpring(rotateY, { stiffness: 120, damping: 20 })

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = cardRef.current?.getBoundingClientRect()
    if (!rect) return
    const cx = rect.left + rect.width / 2
    const cy = rect.top + rect.height / 2
    rotateX.set(((e.clientY - cy) / rect.height) * -10)
    rotateY.set(((e.clientX - cx) / rect.width) * 10)
  }

  const handleMouseLeave = () => {
    rotateX.set(0)
    rotateY.set(0)
    setHovered(false)
  }

  return (
    <div className={`group ${className}`}>
      <Link href={`/projects/${project.name.toLowerCase().replace(/\s+/g, '-')}`}>
        <motion.div
          ref={cardRef}
          onMouseMove={handleMouseMove}
          onMouseEnter={() => setHovered(true)}
          onMouseLeave={handleMouseLeave}
          style={{
            rotateX: springRotateX,
            rotateY: springRotateY,
            transformStyle: 'preserve-3d',
            perspective: 800,
          }}
          className="cursor-pointer"
        >
          {/* Image */}
          <div
            className="relative w-full overflow-hidden bg-foreground/10"
            style={{ aspectRatio: '16/9' }}
          >
            <Image
              src={project.images[0]}
              alt={project.name}
              fill
              sizes={sizes}
              className="object-cover"
            />
          </div>

          {/* Info — Pentagram style */}
          <div className="pt-3 flex flex-col gap-1">

            {/* Title */}
            <h3 className="text-[16px] font-medium text-foreground tracking-tight leading-tight">
              {project.name}
            </h3>

            {/* Description */}
            <p className="text-[16px] font-medium text-foreground/60 leading-tight tracking-tight">
              {project.description}
            </p>

            {/* Industry tag — visible on hover */}
            <motion.div
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: hovered ? 1 : 0, y: hovered ? 0 : 6 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="mt-1"
            >
              <span className="inline-block text-[11px] md:text-[12px] bg-foreground/10 font-medium tracking-tight text-foreground rounded-full px-3 py-1">
                {project.industry}
              </span>
            </motion.div>

          </div>
        </motion.div>
      </Link>
    </div>
  )
}
