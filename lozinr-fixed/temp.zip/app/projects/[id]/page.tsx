'use client'

import { motion, useScroll, useTransform } from 'framer-motion'
import { projectsData } from '@/lib/projects-data'
import Image from 'next/image'
import { useRef, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Header from '@/components/header'
import FooterSection from '@/components/footer-section'

export default function ProjectPage() {
  const params = useParams()
  const router = useRouter()
  const projectName = typeof params.id === 'string' ? params.id : 'lozinr'
  const project = projectsData.find(p => p.name.toLowerCase().replace(/\s+/g, '-') === projectName)
  const nextProjectIndex = project ? (projectsData.indexOf(project) + 1) % projectsData.length : 0
  const nextProject = projectsData[nextProjectIndex]
  const [preloaderDone, setPreloaderDone] = useState(true)

  const heroRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ['start start', 'end start'],
  })
  const heroY = useTransform(scrollYProgress, [0, 1], ['0%', '30%'])
  const heroScale = useTransform(scrollYProgress, [0, 1], [1, 1.08])
  const heroOpacity = useTransform(scrollYProgress, [0, 0.8], [1, 0])
  const titleY = useTransform(scrollYProgress, [0, 1], ['0%', '60%'])

  if (!project) {
    return (
      <>
        <Header />
        <main className="min-h-screen bg-[#edefee] flex items-center justify-center">
          <p className="text-[#0e0c0a]/40 text-sm tracking-tight">Project not found</p>
        </main>
        <FooterSection />
      </>
    )
  }

  const validImages = project.images.filter(img => img && img !== '#')

  const creativeWorkSchema = {
    '@context': 'https://schema.org',
    '@type': 'CreativeWork',
    name: project.name,
    description: project.description,
    image: validImages[0] || 'https://lozinr.com/favicon.svg',
    creator: {
      '@type': 'Organization',
      name: 'Lozinr',
      url: 'https://lozinr.com',
    },
    datePublished: new Date(project.year).toISOString(),
  }

  return (
    <>
      <Header preloaderDone={preloaderDone} />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(creativeWorkSchema) }}
      />
      <main className="min-h-screen bg-background">

        {/* ─── Hero ─── */}
        <section ref={heroRef} className="relative h-screen overflow-hidden">

          {/* Parallax image */}
          {validImages[0] && (
            <motion.div
              className="absolute inset-0"
              style={{ y: heroY, scale: heroScale }}
            >
              <Image
                src={validImages[0]}
                alt={project.name}
                fill
                sizes="100vw"
                className="object-cover"
                priority
              />
            </motion.div>
          )}

          {/* Dark gradient overlay */}
          <div className="absolute inset-0" />



          {/* Hero content */}
          <motion.div
            className="absolute bottom-0 left-0 right-0 px-2 lg:px-4 pb-10 md:pb-14 z-20"
            style={{ y: titleY, opacity: heroOpacity }}
          >
            {/* Title */}
            <div className="overflow-hidden">
              <motion.h1
                initial={{ y: '100%' }}
                animate={{ y: 0 }}
                transition={{ duration: 0.85, delay: 0.7, ease: [0.16, 1, 0.3, 1] }}
                className="font-medium tracking-tight text-white leading-none"
                style={{ fontSize: 'clamp(48px, 8vw, 120px)' }}
              >
                {project.name}
              </motion.h1>
            </div>
          </motion.div>
        </section>

        {/* ─── Project Info ─── */}
        <section className="px-2 lg:px-4 py-16 md:py-24">

          {/* Top row — name + meta */}<motion.div initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-80px' }} transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }} className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-10">  <div>    <h2 className="font-medium tracking-tight text-foreground leading-none" style={{ fontSize: 'clamp(32px, 5vw, 64px)' }}    >      {project.name}    </h2>  </div>  <div className="flex gap-8 md:gap-12">    <p className="text-[14px] font-medium text-foreground tracking-tight">      2024    </p>    <p className="text-[14px] font-medium text-foreground tracking-tight">      Brand Identity    </p>  </div>
          </motion.div>

          {/* Divider */}
          <motion.div
            className="w-full h-px bg-foreground/10 mb-10"
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            style={{ originX: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          />

          {/* Single Description */}
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="max-w-[800px] text-[15px] md:text-[16px] text-foreground/70 leading-relaxed tracking-tight font-medium"
          >
            {project.description}
          </motion.p>
        </section>

        {/* ─── Images ─── */}
        <section className="pb-16 md:pb-24">
          <div className="flex flex-col gap-2">
            {validImages.slice(1).map((image, idx) => {
              // Alternate between full width and 2-column
              const isFullWidth = idx % 3 === 0

              if (isFullWidth) {
                return (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: '-60px' }}
                    transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                    className="relative w-screen -mx-[calc(50vw-50%)] overflow-hidden bg-background"
                    style={{ aspectRatio: '16/9' }}
                  >
                    <Image
                      src={image}
                      alt={`${project.name} ${idx + 2}`}
                      fill
                      sizes="100vw"
                      className="object-cover"
                    />
                  </motion.div>
                )
              }

              // Check if we can pair with next
              const nextImage = validImages[idx + 2]
              if (!nextImage || (idx + 1) % 3 === 0) {
                return (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: '-60px' }}
                    transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                    className="relative w-screen -mx-[calc(50vw-50%)] overflow-hidden bg-gray-100"
                    style={{ aspectRatio: '16/9' }}
                  >
                    <Image
                      src={image}
                      alt={`${project.name} ${idx + 2}`}
                      fill
                      sizes="100vw"
                      className="object-cover"
                    />
                  </motion.div>
                )
              }

              // 2-column pair
              if ((idx + 1) % 3 !== 0 && idx % 3 !== 0) {
                return null // skip — rendered in pair below
              }

              return (
                <motion.div
                  key={idx}
                  className="grid grid-cols-2 gap-2"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-60px' }}
                  transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                >
                  {[image, nextImage].map((img, i) => (
                    <div
                      key={i}
                      className="relative overflow-hidden bg-gray-100"
                      style={{ aspectRatio: '4/3' }}
                    >
                      <Image
                        src={img}
                        alt={`${project.name}`}
                        fill
                        sizes="50vw"
                        className="object-cover"
                      />
                    </div>
                  ))}
                </motion.div>
              )
            })}
          </div>
        </section>



      </main>
      <FooterSection />
    </>
  )
}
