'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import Header from '@/components/header'
import FooterSection from '@/components/footer-section'

export default function ContactClient() {
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  return (
    <main className="min-h-screen bg-background flex flex-col">
      <Header preloaderDone={true} />

      <section className="flex-1 flex flex-col px-2 lg:px-4 pt-20 lg:pt-36">
        {/* Header */}
        <motion.h1
    initial={{ y: '100%', opacity: 0 }}
    animate={isMounted ? { y: 0, opacity: 1 } : { y: '100%', opacity: 0 }}
    transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
    className="text-[59px] lg:text-[160px] flex items-center font-regular text-foreground tracking-tighter text-left leading-tight"
  >
    Contact us
  </motion.h1>

        {/* Calendly Embed */}
        <motion.div
          initial={{ y: 40, opacity: 0 }}
          animate={isMounted ? { y: 0, opacity: 1 } : { y: 40, opacity: 0 }}
          transition={{
            duration: 0.6,
            delay: 0.4,
            ease: 'easeOut'
          }}
          className="w-full flex-1 py-10 lg:py-20 bg-background"
        >
          <iframe
            src="https://cal.com/adnanakif/30-min-meeting?embed=true"
            width="100%"
            height="100%"
            frameBorder="0"
            title="Schedule a meeting"
            className="min-h-[600px] sm:min-h-[700px] md:min-h-[800px]"
          />
        </motion.div>
      </section>

      <FooterSection />
    </main>
  )
}
