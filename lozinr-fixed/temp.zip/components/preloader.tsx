'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

interface PreloaderProps {
  onComplete: () => void
}

const PATH_L = "M418.5,759.33H8.53v-128.19h252.73L132.3,4.61h130.87l48.05,233.47c-28.75,40.63-45.64,90.25-45.64,143.8,0,89.9,47.6,168.69,118.98,212.54l7.57,36.71,26.37,128.19Z"
const PATH_C = "M549.38,131.41c-7.57,0-15.07.35-22.46,1.03h-.03c-97.02,8.93-177.45,75.11-207.22,164.46-8.03,24.07-12.37,49.82-12.37,76.58,0,61.79,23.17,118.18,61.27,160.95,39.66,44.53,95.51,74.31,158.32,80.09h.03c7.39.68,14.89,1.03,22.46,1.03,133.71,0,242.09-108.38,242.09-242.08s-108.38-242.08-242.09-242.08ZM432.73,373.49c0-64.43,52.23-116.66,116.65-116.66s116.66,52.23,116.66,116.66-52.23,116.66-116.66,116.66-116.65-52.23-116.65-116.66Z"

// Strategy: render SVG at MAX display size (scale * base).
// Then animate from scale(base/max) up to scale(1) — so CSS transform never
// exceeds 1x, meaning the browser never upscales a small bitmap.
//
// Base visible size: 82px
// Max visible size: 82 * 5.22 = ~428px → render SVG at 430px
// Start scale: 82/430 = ~0.19  End scale: 1.0  Fly scale: 40/430 = ~0.093

const SVG_RENDER_SIZE = 430   // physical pixels the SVG is drawn at
const BASE_SCALE      = 82  / SVG_RENDER_SIZE   // initial "normal" appearance
const LARGE_SCALE     = 1.0                      // zoomed-in "breath"
const HEADER_LOGO_PX  = { mobile: 36, desktop: 40 }

function getHeaderLogoTarget() {
  const isMobile = window.innerWidth < 768
  const headerLogoSize = isMobile ? HEADER_LOGO_PX.mobile : HEADER_LOGO_PX.desktop
  const paddingLeft    = isMobile ? 8  : 16
  const paddingTop     = isMobile ? 8  : 12

  const targetCX = paddingLeft + headerLogoSize / 2
  const targetCY = paddingTop  + headerLogoSize / 2
  const fromCX   = window.innerWidth  / 2
  const fromCY   = window.innerHeight / 2

  return {
    x:     targetCX - fromCX,
    y:     targetCY - fromCY,
    scale: headerLogoSize / SVG_RENDER_SIZE,
  }
}

type Phase = 'enter' | 'draw' | 'fill' | 'scale' | 'fly' | 'done'

export default function Preloader({ onComplete }: PreloaderProps) {
  const [phase, setPhase]       = useState<Phase>('enter')
  const [flyTarget, setFlyTarget] = useState({ x: 0, y: 0, scale: BASE_SCALE })

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase('draw'),  80),
      setTimeout(() => setPhase('fill'),  1400),
      setTimeout(() => setPhase('scale'), 1820),
      setTimeout(() => {
        setFlyTarget(getHeaderLogoTarget())
        setPhase('fly')
      }, 2380),
      setTimeout(() => onComplete(), 3080),
      setTimeout(() => setPhase('done'),  3220),
    ]
    return () => timers.forEach(clearTimeout)
  }, [onComplete])

  if (phase === 'done') return null

  const isFilled = ['fill', 'scale', 'fly'].includes(phase)
  const isScale  = phase === 'scale'
  const isFly    = phase === 'fly'

  return (
    <div className="fixed inset-0 z-[200] bg-background flex items-center justify-center overflow-hidden">

      <motion.div
        style={{ willChange: 'transform', transformOrigin: 'center center' }}
        initial={{ opacity: 0, scale: BASE_SCALE * 0.88 }}
        animate={
          isFly
            ? { opacity: 1, x: flyTarget.x, y: flyTarget.y, scale: flyTarget.scale }
            : isScale
            ? { opacity: 1, x: 0, y: 0, scale: LARGE_SCALE }
            : { opacity: 1, x: 0, y: 0, scale: BASE_SCALE }
        }
        transition={
          isFly
            ? { duration: 0.72, ease: [0.76, 0, 0.24, 1] }
            : isScale
            ? { scale: { duration: 0.6, ease: [0.34, 1.56, 0.64, 1] }, opacity: { duration: 0.3 } }
            : { duration: 0.55, ease: [0.16, 1, 0.3, 1] }
        }
      >
        <svg
          viewBox="0 0 800 763.93"
          xmlns="http://www.w3.org/2000/svg"
          width={SVG_RENDER_SIZE}
          height={SVG_RENDER_SIZE}
          style={{ display: 'block', overflow: 'visible' }}
        >
          {/* Stroke — draw phase */}
          <motion.path
            d={PATH_L}
            fill="none"
            stroke="currentColor"
            strokeWidth={16}
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-foreground"
            initial={{ pathLength: 0, opacity: 1 }}
            animate={{
              pathLength: phase === 'enter' ? 0 : 1,
              opacity:    isFilled ? 0 : 1,
            }}
            transition={{
              pathLength: { duration: 1.05, ease: [0.16, 1, 0.3, 1] },
              opacity:    { duration: 0.25 },
            }}
          />
          <motion.path
            d={PATH_C}
            fill="none"
            stroke="currentColor"
            strokeWidth={16}
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-foreground"
            initial={{ pathLength: 0, opacity: 1 }}
            animate={{
              pathLength: phase === 'enter' ? 0 : 1,
              opacity:    isFilled ? 0 : 1,
            }}
            transition={{
              pathLength: { duration: 1.18, delay: 0.14, ease: [0.16, 1, 0.3, 1] },
              opacity:    { duration: 0.25, delay: 0.04 },
            }}
          />

          {/* Fill — snaps in as stroke fades */}
          <motion.path
            d={PATH_L}
            fill="currentColor"
            className="text-foreground"
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: isFilled ? 1 : 0, scale: isFilled ? 1 : 0.92 }}
            transition={{
              opacity: { duration: 0.3,  ease: [0.16, 1, 0.3, 1] },
              scale:   { duration: 0.45, ease: [0.16, 1, 0.3, 1] },
            }}
            style={{ transformOrigin: '213px 382px' }}
          />
          <motion.path
            d={PATH_C}
            fill="currentColor"
            className="text-foreground"
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: isFilled ? 1 : 0, scale: isFilled ? 1 : 0.92 }}
            transition={{
              opacity: { duration: 0.3,  delay: 0.05, ease: [0.16, 1, 0.3, 1] },
              scale:   { duration: 0.45, delay: 0.05, ease: [0.16, 1, 0.3, 1] },
            }}
            style={{ transformOrigin: '549px 373px' }}
          />
        </svg>
      </motion.div>

      {/* Background fades out as logo flies to header */}
      <AnimatePresence>
        {isFly && (
          <motion.div
            className="absolute inset-0 bg-background pointer-events-none"
            initial={{ opacity: 1 }}
            animate={{ opacity: 0 }}
            transition={{ duration: 0.55, delay: 0.12, ease: [0.16, 1, 0.3, 1] }}
          />
        )}
      </AnimatePresence>
    </div>
  )
}