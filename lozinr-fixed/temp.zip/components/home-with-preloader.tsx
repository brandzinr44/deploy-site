'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import dynamic from 'next/dynamic'
import Header from '@/components/header'
import HeroSection from '@/components/hero-section'

const Preloader = dynamic(() => import('@/components/preloader'), { ssr: false })

export default function HomeWithPreloader() {
  const [preloaderDone, setPreloaderDone] = useState(false)
  const [triggerHeroAnimation, setTriggerHeroAnimation] = useState(false)

  // Sequence: Preloader → Header animations → Hero animations
  // After preloader completes (3.3s), wait for header nav to finish (0.5s + 0.18s delays)
  // Then trigger hero animations (at ~4.1s total)
  useEffect(() => {
    if (preloaderDone) {
      const heroTimer = setTimeout(() => {
        setTriggerHeroAnimation(true)
      }, 900) // 0.9s delay after preloader completes (lets header nav finish first)
      return () => clearTimeout(heroTimer)
    }
  }, [preloaderDone])

  return (
    <>
      {/* Preloader sits on top (z-200), flies logo to header position, then calls onComplete */}
      {!preloaderDone && (
        <Preloader onComplete={() => setPreloaderDone(true)} />
      )}

      {/*
        Header logo starts invisible (opacity: 0).
        When preloaderDone flips true, the flying logo from Preloader
        is just arriving at the header logo position — at that exact moment
        the header logo fades in (0.18s), creating a seamless handoff.
        Nav links + CTA also stagger in after (delays of 0.12s and 0.18s).
      */}
      <Header preloaderDone={preloaderDone} />

      <main>
        <motion.div
          initial={{ opacity: 0 }}
          animate={preloaderDone ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        >
          <HeroSection triggerAnimation={triggerHeroAnimation} />
        </motion.div>
      </main>
    </>
  )
}
